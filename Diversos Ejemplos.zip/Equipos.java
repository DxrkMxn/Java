import javax.swing.JOptionPane;


public class Equipos 
{
	// Matriz para almacenar informaci�n de los equipos
	static int equipos[][];
	// Lista de nombres de equipos
	static String nombres[] = {"Chelsea", "Arsenal", "Tottenham Hotspur", "West Ham United"};
	
	public static void main(String args[])
	{
		// Creo la matriz de equipo
		// 4 equipos: Chelsea, Arsenal, Tottenham Hotspur y West Ham United
		// Columnas: 0-patidos jugados, 1-partidos ganados, 2-partidos empatados,
		//           3-partidos perdidos, 4-goles a favor, 5-goles en contra,
		//           6-puntos
		equipos = new int [4][7];
		
		// Lleno la matriz, y pido por cada equipo los 5 datos
		for (int i = 0; i < equipos.length; i++)
		{
			// Solicito los partidos jugados
			equipos[i][0] =  Integer.parseInt(JOptionPane.showInputDialog("Cantidad de partidos jugados por "+ nombres[i]));

			// Solicito los partidos ganados
			equipos[i][1] =  Integer.parseInt(JOptionPane.showInputDialog("Cantidad de partidos ganados por "+ nombres[i]));
			 
			// Solicito los partidos empatados
			equipos[i][2] =  Integer.parseInt(JOptionPane.showInputDialog("Cantidad de partidos empatados por "+ nombres[i]));

			// Calculo los partidos perdidos, total menos ganados y menos empatados
			equipos[i][3] = equipos[i][0] - equipos[i][1] - equipos[i][2];
			
			// Solicito los goles a favor
			equipos[i][4] =  Integer.parseInt(JOptionPane.showInputDialog("Cantidad de goles a favor del equipo "+ nombres[i]));

			// Solicito los goles en contra
			equipos[i][5] =  Integer.parseInt(JOptionPane.showInputDialog("Cantidad de goles en contra del equipo "+ nombres[i]));
			
			// Calculo los puntos.  1 por partido empatado y 3 por partido ganado
			equipos[i][6] = equipos[i][2] + 3*equipos[i][1];
		}
		
		// Muestro los datos
		for (int i = 0; i < equipos.length; i++)
		{
			System.out.print(nombres[i]);
			for (int j = 0; j < 7; j++)
			{
				System.out.print("\t" + equipos[i][j]);
			}
			System.out.println("");
		}
		
		// Busco el que m�s puntos tiene, el que menos tiene y el que meti� m�s goles
		int equMasPun = 0;
		int masPunt = equipos[0][6];
		
		int equMenPun = 0;
		int menPunt = equipos[0][6];
		
		int equMasGol = 0;
		int masGol = equipos[0][4];
		
		// Recorro los equipos del 1 en adelante
		for (int i = 1; i < equipos.length; i++)
		{
			// Verifico si hay equipo con mas puntos
			if ( equipos[i][6] > masPunt)
			{
				masPunt = equipos[i][6];
				equMasPun = i;
			}

			// Verifico si hay equipo con menos puntos
			if ( equipos[i][6] < menPunt)
			{
				menPunt = equipos[i][6];
				equMenPun = i;
			}
			
			// Verifico si hay equipo con mas goles
			if ( equipos[i][4] > masGol)
			{
				masGol = equipos[i][4];
				equMasGol = i;
			}
		}	
		
		// Muestro el resultado
		JOptionPane.showMessageDialog(null, "El equipo con m�s puntos es: " + nombres[equMasPun] + ", " + 
				                            "El equipo con menos puntos es: " + nombres[equMenPun] + ", y " + 
				                            "El equipo con m�s goles es: " + nombres[equMasGol] );
	}
}
