package facmaceuta;

import javax.swing.JOptionPane;

public class Farmaceuta
{
   // ---------
   // Variables
   // ---------

   // Listado de s�ntomas
   static String listaSintomas[] = {"Congesti�n Nasal", "Dolor de Cabeza", "Dolor Muscular", "Fiebre Moderada (> 37 y <= 38.5)", "Fiebre Alta (> 38.5)"};
   // Variable para calcular si la temperatura es alta o moderada
   static float temperatura = 0;
   // Arregla en donde se guarda que s�ntomas tiene el paciente
   static boolean sintomas[];
   // Variable temporal para verificar que digita el usuario
   static String resp = null;
   
   // Punto de inicio del programa
   public static void main(String[] args)
   {
      // Inicializo el arreglo de s�ntomas
	   sintomas = new boolean[4]; 
      // Recorro la lista de s�ntomas
      for (int i = 0; i < 4; i++)
      {
         // Pregunto por cada uno de los s�ntomas para ver si los tiene o no   
         resp = JOptionPane.showInputDialog("Presenta " + listaSintomas[i] + "?");

         // Verifico si se trata del s�ntoma 3, es decir que tiene fiebre
         if ( i == 3 )
         {
            // Si no tiene fiebre, coloco fiebre moderada y alta en falso.  No tiene fiebre!
            if ( resp.equalsIgnoreCase("NO") )
            {
               sintomas[3] = false;
            }
            // Significa que si tiene fiebre, verifico entonces cual
            else
            {
               // Pido la temperatura
               temperatura = Float.parseFloat(JOptionPane.showInputDialog("Cu�nto de temperatura tiene?"));
               // Verifico si es moderada o alta
               if (temperatura > 37 && temperatura <= 38.5)
               {
                   // Significa que tiene fiebre moderada
                   sintomas[3] = true;
               }
               else
               {
            	  // Verifico si es alta
            	  if (temperatura > 38.5)
            	  {
                     // Es alta, as� que de una lo mando al m�dico
                     JOptionPane.showMessageDialog(null, "Usted tiene " + listaSintomas[4] + ", debe ir inmediatamente a URGENCIAS");
                     // Detengo el programa de una
                     return;
            	  }
            	  else
            	  {
            	     // No tiene fiebre
            		 sintomas[3] = false;
            	  }
               }
            }
         }
         else
         {
        	// Verifico la respuesta, esto es para cualquier s�ntoma que no sea fiebre
             if ( resp.equalsIgnoreCase("NO") )
                sintomas[i] = false;
             else
                sintomas[i] = true;
         }
      }
      
      // Imprimo los s�ntomas para ver verificar
      for (int i = 0; i < 4; i++)
    	  System.out.println(listaSintomas[i] + " --> " + sintomas[i]);

      // Verifique que sintomas tiene para recetarle, comienzo por el de mayor restricci�n
      if ( sintomas[0] && sintomas[1] && sintomas[2] && sintomas[3] )
         JOptionPane.showMessageDialog(null, "Tome un antigripal");
      else
      {
         if ( sintomas[1] && sintomas[3] )
            JOptionPane.showMessageDialog(null, "Tome una acetaminofen");
         else
         {
            if ( sintomas[2] )
               JOptionPane.showMessageDialog(null, "Tome una aspirina");
            else
               if ( sintomas[3] )
                  JOptionPane.showMessageDialog(null, "Tome un ibuprofeno");
               else
                  JOptionPane.showMessageDialog(null, "No moleste que no tiene nada!");
         }
      }
   }
}