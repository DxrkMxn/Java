import javax.swing.JOptionPane;

public class Distancias
{
	static String[] ciudades = {"Cali", "Bogot�", "Medell�n", "Barraquilla", "C�cuta"};
	static float[][] distancias;
	static String distancia = null;
	static int tamanio = 5;

	public static void main(String[] args)
	{
		distancias = new float[tamanio][tamanio];

		for (int i = 0; i < tamanio; i++)
		{
			for (int j = 0; j < tamanio; j++)
			{
				if ( i == j )
					distancias[i][j] = 0;
				else
				{
					distancia = JOptionPane.showInputDialog("Favor digitar la distancia que hay de " + ciudades[i] + " a " + ciudades[j]);
					distancias[i][j] = Float.parseFloat(distancia);
				}
			}
		}
		imprimir();
		calcularMayoryMenor();
	}

	public static void imprimir()
	{
		System.out.print("       ");
		for (int j = 0; j < tamanio; j++)
		{
			System.out.print(ciudades[j] + ", ");
		}
		System.out.println("");

		for (int i = 0; i < tamanio; i++)
		{
			System.out.print(ciudades[i] + "  ");
			for (int j = 0; j < tamanio; j++)
			{
				System.out.print(distancias[i][j] + ", ");
			}
			System.out.println("");
		}
	}

	public static void calcularMayoryMenor()
	{
		float mayor = distancias[0][1];
		int filaM = 0;
		int colM = 1;

		float menor = distancias[0][1];
		int film = 0;
		int colm = 1;

		for (int i = 0; i < tamanio; i++)
		{
			for (int j = 0; j < tamanio; j++)
			{
				if ( i != j && distancias[i][j] > mayor )
				{
					mayor = distancias[i][j];
					filaM = i;
					colM = j;
				}
				if ( i != j && distancias[i][j] < menor)
				{
					menor = distancias[i][j];
					film = i;
					colm = j;
				}
			}
		}     
		JOptionPane.showMessageDialog(null, "Las dos ciudades m�s lejanas son: " + ciudades[filaM] + " y " + ciudades[colM] + ", con una distancia de " + mayor + "Kms. " + 
				                            "Las dos ciudades m�s cercanas son: " + ciudades[film] + " y " + ciudades[colm] + ", con una distancia de " + menor + "Kms. " );
	}

}

