package clase;

import javax.swing.JOptionPane;

public class Parqueadero
{
	// Matriz que registra la cantidad de carros, filas = horas del d�a, columnas = dias de la semana
	static int cantidadCarros[][];
	// Arreglo con los nombres de los d�as de la semana
	static String dias[] = {"Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado", "Domingo"};

	public static void main (String args[])
	{
		// Inicializo el arreglo en el que se guarda el n�mero de carros
		cantidadCarros = new int[24][7];

		// ---------------------- Captura de Datos -----------------------

		// Se solicita el n�mero de carros que han ingresado un d�a y una hora dada
		int dia = 0;
		int hora = 0;
		// La entrada de datos se realiza hasta que el usuario digite N
		char seguir = 'S';
		// Sigo hasta que el usuario indique que quiere parar
		while ( seguir == 'S' )
		{
			// Pregunto si desea continuar
			seguir = JOptionPane.showInputDialog("Desea ingresar una cantidad? Digite S o N").charAt(0);
			// Si la respuesta es no, me detengo
			if ( seguir == 'N' )
				break;
			else
			{
				// Pido la informaci�n
				dia = Integer.parseInt(JOptionPane.showInputDialog("Favor digitar el d�a de la semana a registrar, teniendo en cuenta que 0 es lunes y 6 domingo!!!!"));
				hora = Integer.parseInt(JOptionPane.showInputDialog("Favor digitar la hora militar del d�a a registrar, teniendo en cuenta que 0 es media noche!!!!"));
				// La registro
				cantidadCarros[hora][dia] = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de carros que ingresaron el " + dias[dia] + " a las " + hora));
			}
		}

		// ---------------------- Validaci�n de Datos Registrados -----------------------

		// Imprimo la matriz para ver como qued� registrado, por control
		// Primero el t�tulo de la tabla
		System.out.print("Hora  ");     
		// El nombre de los d�as
		for (int i = 0; i < 7; i++)
			System.out.print( dias[i] + "  ");
		// Salto una l�nea
		System.out.println();

		// Recorro las horas del d�a 0 = media noche
		for (int j = 0; j < 24; j++)
		{
			// Coloco la hora
			System.out.print("  " + j + "   ");
			// Recorro los d�as
			for (int i = 0; i < 7; i++)
				System.out.print("  " + cantidadCarros[j][i] + "      ");
			// Salto una l�nea
			System.out.println();
		}

		// ---------------------- Estad�sticas Puntuales -----------------------
		JOptionPane.showMessageDialog(null, "El d�a con m�s carros fue " + dias[diaMayor()]);
		JOptionPane.showMessageDialog(null, "La hora con m�s carros fue " + horaMayor());
		JOptionPane.showMessageDialog(null, "El  promedio de carros entre las 2 y 6, el s�bado y domingo fue " + promedio());     
	}

	// Funci�n que regresa el d�a de la semana con m�s carros
	public static int diaMayor()
	{
		// Creo e inicializo un arreglo para almacenar los totales por d�a
		int totalDia[] = new int[7];

		// Calculo la sumatoria por d�a
		// Recorro los d�as
		for (int i = 0; i < 7; i++)
		{
			// Recorro las horas del d�a 0 = media noche
			for (int j = 0; j < 24; j++)
			{
				// Acumulo todas las horas del dia
				totalDia[i] += cantidadCarros[j][i];
			}
		}

		// Verifico cu�l es el d�a con m�s carros
		// Se asume inicialmente el primero como mayor
		int mayor = 0;
		int cantMayor = totalDia[0];
		// Se recorre el arreglo de totales en busca de uno mayor
		for (int i = 1; i < 7; i++)
		{
			// Verifico si el dato actual es mayor
			if ( totalDia[i] > cantMayor)
			{
				// Reemplazo
				cantMayor = totalDia[i];
				mayor = i;
			}
		}

		// Imprimo las sumatorias
		System.out.println();
		System.out.print("      ");
		for (int i = 0; i < 7; i++)
			System.out.print("  " + totalDia[i] + "      ");    

		// Retorno el d�a mayor, no la cantidad
		return mayor;
	}

	// -------------------------------------------------------------------------

	// Funci�n que regresa la hora del d�a con m�s carros
	public static int horaMayor()
	{
		// Creo e inicializo un arreglo para almacenar los totales por hora
		int totalHora[] = new int[24];

		// Calculo la sumatoria por hora
		// Recorro las horas del d�a 0 = media noche
		for (int j = 0; j < 24; j++)
		{
			// Recorro los d�as
			for (int i = 0; i < 7; i++)
			{
				// Acumulo todos los dias de la semana
				totalHora[j] += cantidadCarros[j][i];
			}
		}

		// Verifico cu�l es la hora con m�s carros
		// Se asume inicialmente la primera como mayor
		int mayor = 0;
		int cantMayor = totalHora[0];
		// Se recorre el arreglo de totales en busca de una mayor
		for (int i = 1; i < 24; i++)
		{
			// Verifico si el dato actual es mayor
			if ( totalHora[i] > cantMayor)
			{
				// Reemplazo
				cantMayor = totalHora[i];
				mayor = i;
			}
		}

		// Imprimo las sumatorias
		System.out.println("\nLos totales por hora");
		for (int i = 0; i < 24; i++)
			System.out.println(i + "--> " + totalHora[i]);    

		// Retorno la hora mayor, no la cantidad
		return mayor;
	}

	public static float promedio()
	{
		// Donde voy a guardar el promedio
		float promed = 0;
		
		// Recorro las horas (dentro del rango de 2 a 6 de la tarde), los d�as s�bado y domingo
		for (int j = 14; j <= 18; j++)
			// Acumulo la cantidad de carros del s�bado y domingo
			promed += (cantidadCarros[j][5] + cantidadCarros[j][6]);

		// La cantidad de casillas acumuladas fueron:
		// De 2 a 6 de la tarde hay 4 horas y solo dos d�as, osea 8 casillas
		promed = promed / 8;
				
		// Retorno el promedio
		return promed;
	}
}