import javax.swing.JOptionPane;

public class Villachica 
{
	// N�mero de bloques
	static int cantBloques;
	// Arreglo que se utiliza para almacenar el indice de ocupaci�n por bloque
	static float bloques[];

	// Punto de arranque del programa
	public static void main(String[] args)
	{
		// Solicito el n�mero de bloques
		cantBloques = Integer.parseInt(JOptionPane.showInputDialog("Cu�ntos bloques hay en Villachica?"));
		// Creo el arreglo del tama�o de bloques que necesito
		bloques = new float[cantBloques];
		// Cantidad de pisos por bloque
		int pisos = 0;
		// Total de apatamentos en el bloque
		int aptos = 0;
		// Total de apartamentos ocupados
		int ocup = 0;
		
		// Hago un ciclo de la cantidad de bloques
		for (int i = 0; i < cantBloques; i++)
		{
			// Inicializo en 0 los contadores de cada bloque
			aptos = 0;
			ocup = 0;
			// Para cada bloque pregunto cuantos pisos hay
			pisos = Integer.parseInt(JOptionPane.showInputDialog("Cu�ntos pisos tiene el bloque " + i + "?"));
			// Segundo ciclo, por cada piso pregunto cuantos apto hay en total y cuantos ocupados
			for (int j = 0; j < pisos; j++)
			{
				// Pido cuantos apartamentos tiene ese piso de ese bloque				
				aptos +=  Integer.parseInt(JOptionPane.showInputDialog("Cu�ntos apartamentos tiene el piso " + j + "?"));
				// Pido cuantos de esos apartamentos, de ese piso y bloque, est�n ocupados 
				ocup +=  Integer.parseInt(JOptionPane.showInputDialog("Cu�ntos de esos apartamentos est�n ocupados?"));
			}
			// Una vez recorridos todos los pisos del bloque, calculo el �ndice de ocupaci�n del bloque
			bloques[i] = (float)ocup/(float)aptos;
		}
		
		// Recorro el arreglo e imprimo el contenido para ver si qued� bien el c�lculo
		for (int i = 0; i < cantBloques; i++)
			// Imprimo el indice de ocupaci�n del bloque
			System.out.println("Indice de ocupaci�n del bloque " + i + "; " + bloques[i]);
		
		// Busque el bloque con el �ndice de ocupaci�n menor
		// Asumo que el primer bloque es el valor menor
		int bloqMenor = 0;
		float indiceMenor = bloques[0];
		
		//Recorro el arreglo de bloques buscando un valor menor al primero
		// Inicio en 1 porque ya coloqu� al 0 como menor
		for (int i = 1; i < cantBloques; i++)
		{
			// Verifico si el �ndice del bloque actual es menor que el que hasta ahora es el menor
			if ( bloques[i] < indiceMenor )
			{
				// Si es el caso, reemplazo el �ndice que hasta ahora era el menor
				indiceMenor = bloques[i];
				// Reemplazo el bloque 
				bloqMenor = i;
			}
		}
		
		// Imprimo el resultado
		JOptionPane.showMessageDialog(null, "El menor �ndice de ocupaci�n es: " + indiceMenor + " y lo tiene el bloque " + bloqMenor);
	}
}
