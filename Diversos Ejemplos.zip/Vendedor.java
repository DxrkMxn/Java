package clase;

import javax.swing.JOptionPane;

public class Vendedor
{
	// Matriz para guardar la informaci�n de los productos y vendedores
	static int unidadesVendidas[][];
	// Arreglo para almacenar el total por Vendedor
	static int vendedores[];
	// Arreglo para almacenar el total por Producto
	static int productos[];
	
	public static void main(String[] args)
	{
		// Inicializo el arreglo de productos (5), vendedores (4)
		unidadesVendidas = new int [5][4];
		
		// Inicializo los arreglos de totales
		vendedores = new int[4];
		productos = new int[5];
		
		// Pido los datos de las unidades vendidas por producto y por vendedor
		// Recorro los vendedores
		for (int j = 0; j < 4; j++)
			// Recorro los productos
			for (int i = 0; i < 5; i++)
				// Pido la cantidad de unidades vendidas
				unidadesVendidas[i][j] = Integer.parseInt(JOptionPane.showInputDialog("Digite el N�mero de Unidades Vendidas por el Vendedor " + j + ", del producto " + i));
		
		// Imprimo lo almacenado
		// Titulo Vendedores
		System.out.print("Productos");
		for (int j = 0; j < 4; j++)
			System.out.print("  V" + j + "  ");
		System.out.println("");
		
		// Recorro los productos
		for (int i = 0; i < 5; i++)
		{
			System.out.print("     "+ i + "      ");
			// Recorro los vendedores
			for (int j = 0; j < 4; j++)
				System.out.print(unidadesVendidas[i][j] + "   ");
			System.out.println("");
		}
		
		totalPorVendedor();
		totalPorProducto();
		vendedorEstrella();
		productoMasVendido();
		promedioDeVentasProducto(Integer.parseInt(JOptionPane.showInputDialog("Digite el N�mero del producto a promediar")));
	}
	
	// ----------------------- Total por Vendedor -----------------
	
	public static void totalPorVendedor()
	{
		// Recorro los vendedores
		for (int j = 0; j < 4; j++)
			// Recorro lor productos
			for (int i = 0; i < 5; i++)
				// Acumulo todos los productos por vendedor
				vendedores[j] += unidadesVendidas[i][j];

		// Imprimo las sumatorias
		System.out.println("\n Unidades por vendedor");
		for (int i = 0; i < 4; i++)
			System.out.println(i + "--> " + vendedores[i]);
	}

	// ----------------------- Total por Producto -----------------
	
	public static void totalPorProducto()
	{
		// Recorro lor productos
		for (int i = 0; i < 5; i++)
			// Recorro los vendedores
			for (int j = 0; j < 4; j++)
				// Acumulo todos los vendedores por producto
				productos[i] += unidadesVendidas[i][j];

		// Imprimo las sumatorias
		System.out.println("\n Unidades por producto");
		for (int i = 0; i < 5; i++)
			System.out.println(i + "--> " + productos[i]);
	}

	// ----------------------- Vendedor que mas Vende -----------------
	
	public static void vendedorEstrella()
	{
		// Asumo que el mejor es el primer vendedor
		int mayor = 0;
		int cantMayor = vendedores[0];
		
		// Recorro los totales de los vendedores
		for (int j = 1; j < 4; j++)
			// Verifico si es mayor este nuevo vendedor
			if ( vendedores[j] > cantMayor )
			{
				// En caso de haber vendido mas, debe almacenarlo como nuevo vendedor estrella
				cantMayor = vendedores[j];
				mayor = j; 
			}

		// Imprimo el resultado
		System.out.println("\nEl vendedor estrella es " + mayor + " con " + cantMayor + " unidades vendidas");
	}
	// ----------------------- Producto mas Vendido -----------------
	
	public static void productoMasVendido()
	{
		// Asumo que el mas vendido es el primer producto
		int mayor = 0;
		int cantMayor = productos[0];
		
		// Recorro los totales de los productos
		for (int i = 1; i < 4; i++)
			// Verifico si es mayor este nuevo producto
			if ( productos[i] > cantMayor )
			{
				// En caso de haber sido vendido mas, debe almacenarlo como nuevo producto mas vendido
				cantMayor = productos[i];
				mayor = i; 
			}

		// Imprimo el resultado
		System.out.println("El producto m�s vendido es " + mayor + " con " + cantMayor + " unidades vendidas");
	}	
	
	// ----------------------- Promedio de Ventas de un Producto Dado -----------------

	// Rrecibe por par�metro el producto al que le va a sacar el promedio
	public static void promedioDeVentasProducto(int prod)
	{
		// El promedio ser�a la cantidad total del producto, que ya est� calculada,
		// entre la cantidad de vendedores, osea 4
		System.out.println("El promedio del producto " + prod + " es: " + (productos[prod] / 4) );
	}

}