//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//																																//
//																																//
//Desarrollo:				IMPRIMIR ARREGLO 5X5 EN ESPIRAL	Y NUMEROS PARES EN JAVA												//
//Desarrollador:			Ing. Jhusef Alfonso Lopez Parra  																	//
//																																//
//																																//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//	  ------ Inicio ------    ------ Inicio ------    ------ Inicio ------    ------ Inicio ------    ------ Inicio ------  	//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------------------------------------------------//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

// � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �  //
//  � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � //
// � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �  //
//  � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � //

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
package principal; // Definici�n del nombre del Paquete
import java.util.Scanner; // Se importa la libreria para realizar Scanner
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 */
public class Principal { // Declaracion del metodo principal
    /**
     * @param Se definen constasntes y el arreglo a trabajar
     */
    final int FILAS=5, COLS=5; // Definici�n de constantes
    int espiral[][]; // Definici�n del arreglo espiral
    //METODO PRINCIPAL:
    public static void main(String[] args) {
        // TODO Aqu� se listan los algoritmos a realizar
        Principal miPrograma = new Principal(); // Se invoca un constructor usando NEW
        //Algoritmos definidos en clase:
        miPrograma.HolaMundo(); // Mensaje muy com�n usado en programacion
        miPrograma.leerDatos(); // Ingresar datos al arreglo
        miPrograma.imprimirDatos(); // Muestra los datos del arreglo como se solicitaron
    } // Se cierra el METODO PRINCIPAL.
    //Se inicia en espacio de memoria el arreglo con un tama�o de FILASxCOLS
    public Principal(){ // Inicio de la construccion del arreglo
          espiral = new int[FILAS][COLS]; // Se define el arreglo con su dimesi�n
    } // Se cierra
    void HolaMundo(){ // Se inicia el algoritmo que muestra el mensaje de inicio.
        System.out.print("Hola, Mundo\n\nBienvenidos al programa:\n"); // Mensaje
    } // Cierre del algoritmo que muestra el mensaje de inicio
    void leerDatos(){ // Se inicia el algoritmo que ingresa los datos al arreglo.
        Scanner s = new Scanner(System.in); // Se invoca un constructor para ingresar datos al llamar s
        for(int i=0;i<FILAS;i++){ // Se inicia el primer for para recorrer filas del arreglo
            for(int j=0;j<COLS;j++){ // Se inicia el segundo for para recorrer columnas del arreglo
                System.out.print("\nIngrese valor en la casilla "+(i+1)+"x"+(j+1)+": "); // Se le solicita al usuario ingresar un valor para la posicion dada
                espiral[i][j] = s.nextInt(); // Se realiza el Scanner s para capturar un entero
            } // Se cierra el segundo for que recorre las columnas del arreglo
        } // Se cierra el primer for que recorre las filas del arreglo
        return; // Se retorna el void
    } // Se cierra el algoritmo que ingresa los datos al arreglo
    void imprimirDatos(){ // Se inicia el algoritmo que imprime los datos solicitados
        System.out.print("Impresion de datos:\n\n1. Arreglo Original:\n\n"); // Mensaje que incida que se mostrar� el arreglo ingresado
        for(int i=0;i<FILAS;i++) { // Se inicia el primer for que recorre las filas del arreglo
        	for(int j=0;j<COLS;j++) { // Se inicia el segundo for que recorre las columnas del arreglo
        		System.out.print(+espiral[i][j]+" "); // Se imprime el elemento del arreglo, en la posicion ixj
        	} // Se cierra el segundo for que recorre columnas del arreglo
        	System.out.print("\n"); // Se imprime un salto de l�nea por cadaa cambio de fila
        } // Se cierra el primer for que recorre filas del arreglo
        System.out.print("\n\n2. Numero Pares del Arreglo:\n\n"); // Mensaje que indica que se mostrar�n los n�meros pares del arreglo  
        for(int i=0;i<FILAS;i++) { // Se inicia el primer for que recorre las filas del arreglo
        	for(int j=0;j<COLS;j++) { // Se inicia el segundo for que recorre las columnas del arreglo
        		if(espiral[i][j]%2==0) { // Se realiza una condicional para saber si el n�mero de la posici�n asignada es par
        			System.out.print(+espiral[i][j]+" "); // En caso de que sea par, imprime el n�mero
        		} // Se cierra el condicional sin encesitar declarar un else.
        	} // Se cierra el segundo for que recorre columnas del arreglo 
        } // Se cierra el primer for que recorre filas del arreglo
        // LA TAREA DE LA PRIMER CLASE:
        System.out.print("\n\n3. Numeros del Arreglo expresados en forma de Espiral:\n(Metodo Aristas-Nodos que use en Dev-C++)\n\n"); // Mensaje para indicar que se mostrar�n los elementos del arreglo en forma de espiral y el m�todo usado
        for(int j=0;j<FILAS;j++) { // Se inicia el primer FOR del primer recorrido en L.
        	System.out.print(+espiral[0][j]+", "); // Se imprimen los elementos de la primera arista de la primer L.
        	if(j==4) { // Se pregunta si se lleg� al Nodo que une las dos aristas de la primer L.
        		for(int i=1;i<COLS;i++) { // Se inicia un segundo FOR para recorrer la segunda Arista de la primer L.
        			System.out.print(+espiral[i][4]+", "); // Se imprimen los valores de la segunda Arista de la primer L.
        		} // Se cierra el segundo FOR que recorre la segunda Arista de la primer L.
        	} // Se cierra el IF que preguntaba el Nodo que une las dos Aristas de la primer L.
        } // Se finaliza el primer recorrido en L.
        for(int j=3;j>=0;j--) {  // Se inicia el segundo recorrido en L.
        	System.out.print(+espiral[4][j]+", "); // Se imprimen los elementos de la primer Arista del segundo recorrido en L.
        	if(j==0) { // Se inicia la condicional que evalua si se lleg� al Nodo que une las dos Aristas de la segunda L.
        		for(int i=3;i>=1;i--) {  // Se inicia el recorrido por la segunda Arista del segundo recorrido en L.
        			System.out.print(+espiral[i][0]+", "); // Se imprime los elementos de la segunda Arista de la segunda L.
        		} // Se cierra el FOR que recorre la segunda Arista de la segunda L.
        	} // Se cierra la condicional que evalua si se lleg� al Nodo que une las dos Aristas de la segunda L.
        } // Se cierra el segundo FOR que recorre la segunda L.
        for(int j=1;j<=3;j++) { // Se inicia un tercer recorrido en forma de L en el arreglo.
        	System.out.print(+espiral[1][j]+", ");  // Se imprimen los elementos de la primer arista de la tercer L.
        	if(j==3) {// Se evalua si se lleg� al Nodo que une las dos Aristas del tercer recorrido en forma de L.
        		for(int i=2;i<=3;i++) { // Se inicia un FOR que recorre la segunda Arista de la tercer L.
        			System.out.print(+espiral[i][3]+", ");  // Se imprimen los elementos de la segunda Arista de la tercer L.
        		} // Se finaliza el FOR que recorre la segunda Arista de la tercer L.
        	}// Se cierra la condicional que evalua si se lleg� al Nodo que une las dos Aristas de la tercer L.
        } // Se cierra el FOR que permitia recorrer el arreglo por tercer vez en forma de L.
        for(int j=2;j>=1;j--) { // Se inicia un cuarto y ultimo recorrido en L por el arreglo.
        	System.out.print(+espiral[3][j]+", ");  // Se imprimen los elementos de la primer Arista del cuarto recorrido en L.
        	if(j==1) { // Se evalua si se lleg� al Nodo que une las dos Aristas del cuarto recorrido en L.
        		System.out.print(+espiral[2][1]+", "+espiral[2][2]+"."); // Se imprimen los elementos finales del arreglo.
        	}// Se cierra la condicional que evalua si se lleg� al Nodo que une las dos Aristas del cuarto recorrido en L
        } // Se cierra el cuarto recorrido en forma de L por el arreglo.
        return; // Se retorna la funcion de tipo void.
    } // Se finaliza el recorrido e impresion de los elemtos del arreglo en forma de espiral.
} // Se cierra la llave del METODO PRINCIPAL y con este sus interacciones.------------------------------------------------------//
//******************************************************************************************************************************//
//******************************************************************************************************************************// 
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//


//� � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �   //
//� � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �   //
//� � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �   //
//� � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � � �   //

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------------------------------------------------//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//		  ------- Fin -------    ------- Fin -------    ------- Fin -------    ------- Fin -------    ------- Fin -------  		//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//																																//
//																																//
//Desarrollo:				IMPRIMIR ARREGLO 5X5 EN ESPIRAL	Y NUMEROS PARES EN JAVA												//
//Desarrollador:			Ing. Jhusef Alfonso Lopez Parra  																	//
//																																//
//																																//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
//******************************************************************************************************************************//
