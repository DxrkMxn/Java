package ciudades; // Definicionn del nombre del Paquete
import java.util.Scanner; // Se importa la libreria para realizar Scanner

/**
 *
 * @author Ing Jhusef Alfonso Lopez Parra
 * 
 */

public class Ciudades {

    
    final int FILAS = 5, COLS = 5, cantidadCiudades=5; // Definición de constantes
    int acumulador=0; // Definimos una variable global.
    int distancias[][]; // Se define la matriz donde se almacenaron las distancias
    String ciudades[]={"Cali","Medellin","Bogota","Barranquilla","Leticia"}; // Se define la arreglo del nombre de las ciudades
    //METODO PRINCIPAL:
    public static void main(String[] args) {
        

        
        Ciudades miPrograma = new Ciudades();
        
        miPrograma.IngresarDistancias();
        miPrograma.mayorDistancia();
        miPrograma.menorDistancia();
        
    }
    
    public Ciudades(){
                distancias = new int[FILAS][COLS]; // Se define el arreglo con su dimesion
    }
    
    void IngresarDistancias(){
        Scanner s = new Scanner(System.in); // Se invoca un constructor para ingresar datos al llamar s
        for(int i=0;i<FILAS;i++){
            for(int j=0;j<COLS;j++){
            
                if(i==j){
                    distancias[i][j]=0;
                }
                else{
                    if(j>i){
                        System.out.print("\nIngrese la distancia entre " + ciudades[i] + " y " + ciudades[j] + ": "); // Se le solicita al usuario ingresar un valor para la posicion dada
                        distancias[i][j] = s.nextInt(); // Se realiza el Scanner s para capturar un entero
                        distancias[j][i] = distancias[i][j]; // Se copia el numero ingresado en ixj en jxi
                    }
                }
                
                
            }
        }
    }
    void mayorDistancia(){
        int acuI=0,acuJ=0,i=0,j=0;
        for(i=0;i<FILAS;i++){
            for(j=0;j<COLS;j++){
                if(acumulador<distancias[i][j]){
                    acumulador=distancias[i][j];
                    acuI=i;
                    acuJ=j;
                }
            }
        }
        
        System.out.print("\nLa mayor distancia es " + acumulador + " entre " + ciudades[acuI] + " y " + ciudades[acuJ] + ". ");
        return;
    }
    
    void menorDistancia(){
        int acuI=0,acuJ=0,i=0,j=0;
        for(i=0;i<FILAS;i++){
            for(j=0;j<COLS;j++){
                if(i==j){
                    
                }
                else{
                    
                    if(acumulador>=distancias[i][j]){
                        acumulador=distancias[i][j];
                        acuI=i;
                        acuJ=j;
                    }
                }
            }
        }
        
        System.out.print("\nLa menor distancia es " + acumulador + " entre " + ciudades[acuI] + " y " + ciudades[acuJ] + ". \n");
        
    }
    
    
}
