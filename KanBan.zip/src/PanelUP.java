
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 * @throws java.io.IOException
 */
public class PanelUP extends JPanel {

    //Se inician sus variables con encapsulamiento publico para que el manejo de datos
    // en otras clases sea posible
    public JPanel UP;
    public JPanel up, down;
    public JLabel titulo, logo, planeacion, enproceso, finalizado, espacio;
    public JButton agregar, editar, importar, exportar, salir;
    public int importarUnaVez = 1;

    public PanelUP() throws IOException {

        // Se le empezarÃ¡ a dar valores a sus botones , ya que gracias a estos se ejecutarÃ¡n funciones
        UP = new JPanel();
        UP.setLayout(new GridLayout(2, 1));
        UP.add(arriba());
        UP.add(abajo());
        UP.setVisible(true);

        this.add(UP);

    }

    public JPanel arriba() throws IOException {
        up = new JPanel();
        // Se le da una imagen a los botones , cada uno con su ruta especifica
        logo = new JLabel(new ImageIcon("./src/Imagenes/LOGO.png"));

        agregar = new JButton(new ImageIcon("./src/Imagenes/Agregar.png"));
        agregar.setBorder(null);
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                // Cuando se pulse el botÃ³n de agregar Post-it se ejecutarÃ¡ la funciÃ³n correspondiente
                //Mostrando y pidiendo datos que el Post-it requiere para ser guardado
                String Anombre = JOptionPane.showInputDialog("Nombre de la persona encargada o del Equipo asignado:");
                String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");

                String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                String[] Aproceso = {"Planeacion", "En Proceso", "Finalizado"};

                // Se crean objetos de la clase PanelUp y que solo se muestren con la funcion de agregar
                // mostrarÃ¡n un mensaje y seguido a ello pedirÃ¡n unos datos para creacion de post-it
                Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);

                //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando 
                if ((opcionPrio.equals("Baja Prioridad")) && (opcionPro.equals("Planeacion"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Planeacion";
                    Postit[3] = "Baja Prioridad";
                    int d = ((Desarrollador.PI1[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI1[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI1[0][i];
                        Aumentar[1][i] = Desarrollador.PI1[1][i];
                        Aumentar[2][i] = Desarrollador.PI1[2][i];
                        Aumentar[3][i] = Desarrollador.PI1[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Baja Prioridad";
                    Desarrollador.PI1 = Aumentar;
                    Desarrollador.contadores[0] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });         // Se usa herencia para agregar el Post-it en la region 1 del KanBan
                    PanelBoard.KB1.add(NPostIt);
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Mediana Prioridad")) && (opcionPro.equals("Planeacion"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Planeacion";
                    Postit[3] = "Mediana Prioridad";
                    int d = ((Desarrollador.PI4[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI4[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI4[0][i];
                        Aumentar[1][i] = Desarrollador.PI4[1][i];
                        Aumentar[2][i] = Desarrollador.PI4[2][i];
                        Aumentar[3][i] = Desarrollador.PI4[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Mediana Prioridad";
                    Desarrollador.PI4 = Aumentar;
                    Desarrollador.contadores[3] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    }); // Se usa herencia para agregar el Post-it en la region 4 del KanBan
                    PanelBoard.KB4.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Alta Prioridad")) && (opcionPro.equals("Planeacion"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Planeacion";
                    Postit[3] = "Alta Prioridad";
                    int d = ((Desarrollador.PI7[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI7[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI7[0][i];
                        Aumentar[1][i] = Desarrollador.PI7[1][i];
                        Aumentar[2][i] = Desarrollador.PI7[2][i];
                        Aumentar[3][i] = Desarrollador.PI7[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Alta Prioridad";
                    Desarrollador.PI7 = Aumentar;
                    Desarrollador.contadores[6] += 1;
                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo

                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });    // Se usa herencia para agregar el Post-it en la region 7 del KanBan
                    PanelBoard.KB7.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Baja Prioridad")) && (opcionPro.equals("En Proceso"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "En Proceso";
                    Postit[3] = "Baja Prioridad";
                    int d = ((Desarrollador.PI2[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI2[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI2[0][i];
                        Aumentar[1][i] = Desarrollador.PI2[1][i];
                        Aumentar[2][i] = Desarrollador.PI2[2][i];
                        Aumentar[3][i] = Desarrollador.PI2[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "En Proceso";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Baja Prioridad";
                    Desarrollador.PI2 = Aumentar;
                    Desarrollador.contadores[1] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });// Se usa herencia para agregar el Post-it en la region 2 del KanBan
                    PanelBoard.KB2.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Mediana Prioridad")) && (opcionPro.equals("En Proceso"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "En Proceso";
                    Postit[3] = "Mediana Prioridad";
                    int d = ((Desarrollador.PI5[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI5[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI5[0][i];
                        Aumentar[1][i] = Desarrollador.PI5[1][i];
                        Aumentar[2][i] = Desarrollador.PI5[2][i];
                        Aumentar[3][i] = Desarrollador.PI5[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "En Proceso";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Mediana Prioridad";
                    Desarrollador.PI5 = Aumentar;
                    Desarrollador.contadores[4] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    }); // Se usa herencia para agregar el Post-it en la region 5 del KanBan
                    PanelBoard.KB5.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Alta Prioridad")) && (opcionPro.equals("En Proceso"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "En Proceso";
                    Postit[3] = "Alta Prioridad";
                    int d = ((Desarrollador.PI8[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI8[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI8[0][i];
                        Aumentar[1][i] = Desarrollador.PI8[1][i];
                        Aumentar[2][i] = Desarrollador.PI8[2][i];
                        Aumentar[3][i] = Desarrollador.PI8[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "En Proceso";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Alta Prioridad";
                    Desarrollador.PI8 = Aumentar;
                    Desarrollador.contadores[7] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });// Se usa herencia para agregar el Post-it en la region 8 del KanBan
                    PanelBoard.KB8.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Baja Prioridad")) && (opcionPro.equals("Finalizado"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Finalizado";
                    Postit[3] = "Baja Prioridad";
                    int d = ((Desarrollador.PI3[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI3[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI3[0][i];
                        Aumentar[1][i] = Desarrollador.PI3[1][i];
                        Aumentar[2][i] = Desarrollador.PI3[2][i];
                        Aumentar[3][i] = Desarrollador.PI3[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Baja Prioridad";
                    Desarrollador.PI3 = Aumentar;
                    Desarrollador.contadores[4] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });// Se usa herencia para agregar el Post-it en la region 3 del KanBan
                    PanelBoard.KB3.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Mediana Prioridad")) && (opcionPro.equals("Finalizado"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Finalizado";
                    Postit[3] = "Mediana Prioridad";
                    int d = ((Desarrollador.PI6[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI6[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI6[0][i];
                        Aumentar[1][i] = Desarrollador.PI6[1][i];
                        Aumentar[2][i] = Desarrollador.PI6[2][i];
                        Aumentar[3][i] = Desarrollador.PI6[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Mediana Prioridad";
                    Desarrollador.PI6 = Aumentar;
                    Desarrollador.contadores[5] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    });// Se usa herencia para agregar el Post-it en la region 6 del KanBan
                    PanelBoard.KB6.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                } //Se ejecutan las siguientes condicionales para saber en que region del KanBan va a ir
                //Ubicado el Post-it que se estÃ¡ creando
                else if ((opcionPrio.equals("Alta Prioridad")) && (opcionPro.equals("Finalizado"))) {
                    JButton NPostIt = new JButton(Anombre);
                    String[] Postit = new String[4];

                    Postit[0] = (Anombre);
                    Postit[1] = (Atarea);
                    Postit[2] = "Finalizado";
                    Postit[3] = "Alta Prioridad";
                    int d = ((Desarrollador.PI9[0].length) + 1);
                    String Aumentar[][] = new String[4][d];
                    for (int i = 0; i < Desarrollador.PI9[0].length; i++) {
                        Aumentar[0][i] = Desarrollador.PI9[0][i];
                        Aumentar[1][i] = Desarrollador.PI9[1][i];
                        Aumentar[2][i] = Desarrollador.PI9[2][i];
                        Aumentar[3][i] = Desarrollador.PI9[3][i];

                    }
                    Aumentar[0][(Aumentar[0].length) - 1] = (Anombre);
                    Aumentar[1][(Aumentar[0].length) - 1] = (Atarea);
                    Aumentar[2][(Aumentar[0].length) - 1] = "Planeacion";
                    Aumentar[3][(Aumentar[0].length) - 1] = "Alta Prioridad";
                    Desarrollador.PI9 = Aumentar;
                    Desarrollador.contadores[8] += 1;

                    NPostIt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent arg0) {
                            // La funcion solo se ejecutarÃ¡ si se le hace click al post-it creado 
                            // procederÃ¡ a mostrar la informacion que el usuario introdujo
                            JFrame mostrar;
                            mostrar = new JFrame();
                            mostrar.setSize(400, 300);
                            mostrar.setResizable(false);
                            mostrar.setLocationRelativeTo(null);
                            mostrar.setVisible(true);
                            mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                            JLabel n = new JLabel("  Nombre: ");
                            mostrar.add(n);
                            JLabel N = new JLabel(Postit[0]);
                            mostrar.add(N);
                            JLabel t = new JLabel("  Tarea: ");
                            mostrar.add(t);
                            JLabel T = new JLabel(Postit[1]);
                            mostrar.add(T);
                            JLabel p = new JLabel("  Se encuentra en: ");
                            mostrar.add(p);
                            JLabel P = new JLabel(Postit[2]);
                            mostrar.add(P);
                            JLabel q = new JLabel("  Prioridad: ");
                            mostrar.add(q);
                            JLabel Q = new JLabel(Postit[3]);
                            mostrar.add(Q);

                        }
                    }); // Se usa herencia para agregar el Post-it en la region 9 del KanBan
                    PanelBoard.KB9.add(NPostIt);
                    //Se actualiza la interfaz para que muestre los datos guardados
                    updateUI();
                }
                updateUI();
            }
        });

        editar = new JButton(new ImageIcon("./src/Imagenes/Editar.png"));
        // Se le da una imagen a el boton editar y se agrega en el panel
        editar.setBorder(null);

        editar.addActionListener(new ActionListener() {
            //Acciones a desarrollar una vez pulsado el botÃ³n editar

            @Override
            public void actionPerformed(ActionEvent arg0) {

                //Se usa herencia para llamar a una funcion de la clase Desarrollador
                String[] OP = {"Eliminar Post-It", "Editar Post-It"};
                Object opcion = JOptionPane.showInputDialog(null, "Selecciona una lo que desear realizar:", "EDITAR/ELIMINAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, OP, OP[1]);

                if (opcion.equals(OP[1])) {

                    String[] Aproceso = {"Planeacion", "En Proceso", "Finalizado"};
                    String[] Aprioridad = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                    Object Prio = JOptionPane.showInputDialog(null, "Seleccione la Prioridad del Post-It a editar:", "EDITAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridad, Aprioridad[0]);
                    Object Proc = JOptionPane.showInputDialog(null, "Seleccione el Proceso del Post-It a editar:", "EDITAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                    if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[0] >= 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI1[0], Desarrollador.PI1[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[0]; i++) {
                            if (Desarrollador.PI1[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[0]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI1[0][i];
                                Guardar[1][i] = Desarrollador.PI1[1][i];
                                Guardar[2][i] = Desarrollador.PI1[2][i];
                                Guardar[3][i] = Desarrollador.PI1[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[0]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI1[0][i];
                                Guardar[1][cont] = Desarrollador.PI1[1][i];
                                Guardar[2][cont] = Desarrollador.PI1[2][i];
                                Guardar[3][cont] = Desarrollador.PI1[3][i];

                            }
                            if (Desarrollador.contadores[0] > 0) {
                                Desarrollador.contadores[0]--;
                            }
                            Desarrollador.PI1 = null;
                            Desarrollador.PI1 = Guardar;

                        } else {
                            Desarrollador.PI1[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[1] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI2[0], Desarrollador.PI2[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[1]; i++) {
                            if (Desarrollador.PI2[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[1]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI2[0][i];
                                Guardar[1][i] = Desarrollador.PI2[1][i];
                                Guardar[2][i] = Desarrollador.PI2[2][i];
                                Guardar[3][i] = Desarrollador.PI2[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[1]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI1[0][i];
                                Guardar[1][cont] = Desarrollador.PI1[1][i];
                                Guardar[2][cont] = Desarrollador.PI1[2][i];
                                Guardar[3][cont] = Desarrollador.PI1[3][i];

                            }
                            if (Desarrollador.contadores[1] > 0) {
                                Desarrollador.contadores[1]--;
                            }
                            Desarrollador.PI2 = null;
                            Desarrollador.PI2 = Guardar;

                        } else {
                            Desarrollador.PI2[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[2] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI3[0], Desarrollador.PI3[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[2]; i++) {
                            if (Desarrollador.PI3[2][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[2]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI3[0][i];
                                Guardar[1][i] = Desarrollador.PI3[1][i];
                                Guardar[2][i] = Desarrollador.PI3[2][i];
                                Guardar[3][i] = Desarrollador.PI3[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[2]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI3[0][i];
                                Guardar[1][cont] = Desarrollador.PI3[1][i];
                                Guardar[2][cont] = Desarrollador.PI3[2][i];
                                Guardar[3][cont] = Desarrollador.PI3[3][i];

                            }
                            if (Desarrollador.contadores[2] > 0) {
                                Desarrollador.contadores[2]--;
                            }
                            Desarrollador.PI3 = null;
                            Desarrollador.PI3 = Guardar;

                        } else {
                            Desarrollador.PI3[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[3] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI4[0], Desarrollador.PI4[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[3]; i++) {
                            if (Desarrollador.PI4[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[3]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI4[0][i];
                                Guardar[1][i] = Desarrollador.PI4[1][i];
                                Guardar[2][i] = Desarrollador.PI4[2][i];
                                Guardar[3][i] = Desarrollador.PI4[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[3]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI4[0][i];
                                Guardar[1][cont] = Desarrollador.PI4[1][i];
                                Guardar[2][cont] = Desarrollador.PI4[2][i];
                                Guardar[3][cont] = Desarrollador.PI4[3][i];

                            }
                            if (Desarrollador.contadores[3] > 0) {
                                Desarrollador.contadores[3]--;
                            }
                            Desarrollador.PI4 = null;
                            Desarrollador.PI4 = Guardar;

                        } else {
                            Desarrollador.PI4[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[4] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI5[0], Desarrollador.PI5[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[4]; i++) {
                            if (Desarrollador.PI5[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[4]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI5[0][i];
                                Guardar[1][i] = Desarrollador.PI5[1][i];
                                Guardar[2][i] = Desarrollador.PI5[2][i];
                                Guardar[3][i] = Desarrollador.PI5[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[4]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI5[0][i];
                                Guardar[1][cont] = Desarrollador.PI5[1][i];
                                Guardar[2][cont] = Desarrollador.PI5[2][i];
                                Guardar[3][cont] = Desarrollador.PI5[3][i];

                            }
                            if (Desarrollador.contadores[4] > 0) {
                                Desarrollador.contadores[4]--;
                            }
                            Desarrollador.PI5 = null;
                            Desarrollador.PI5 = Guardar;

                        } else {
                            Desarrollador.PI5[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[5] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI6[0], Desarrollador.PI6[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[5]; i++) {
                            if (Desarrollador.PI6[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[0]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI6[0][i];
                                Guardar[1][i] = Desarrollador.PI6[1][i];
                                Guardar[2][i] = Desarrollador.PI6[2][i];
                                Guardar[3][i] = Desarrollador.PI6[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[0]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI6[0][i];
                                Guardar[1][cont] = Desarrollador.PI6[1][i];
                                Guardar[2][cont] = Desarrollador.PI6[2][i];
                                Guardar[3][cont] = Desarrollador.PI6[3][i];

                            }
                            if (Desarrollador.contadores[5] > 0) {
                                Desarrollador.contadores[5]--;
                            }
                            Desarrollador.PI6 = null;
                            Desarrollador.PI6 = Guardar;

                        } else {
                            Desarrollador.PI6[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[6] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI7[0], Desarrollador.PI7[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[6]; i++) {
                            if (Desarrollador.PI1[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[6]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI7[0][i];
                                Guardar[1][i] = Desarrollador.PI7[1][i];
                                Guardar[2][i] = Desarrollador.PI7[2][i];
                                Guardar[3][i] = Desarrollador.PI7[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[6]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI7[0][i];
                                Guardar[1][cont] = Desarrollador.PI7[1][i];
                                Guardar[2][cont] = Desarrollador.PI7[2][i];
                                Guardar[3][cont] = Desarrollador.PI7[3][i];

                            }
                            if (Desarrollador.contadores[6] > 0) {
                                Desarrollador.contadores[6]--;
                            }
                            Desarrollador.PI7 = null;
                            Desarrollador.PI7 = Guardar;

                        } else {
                            Desarrollador.PI7[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[7] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI8[0], Desarrollador.PI8[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[7]; i++) {
                            if (Desarrollador.PI8[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[7]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI8[0][i];
                                Guardar[1][i] = Desarrollador.PI8[1][i];
                                Guardar[2][i] = Desarrollador.PI8[2][i];
                                Guardar[3][i] = Desarrollador.PI8[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[7]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI8[0][i];
                                Guardar[1][cont] = Desarrollador.PI8[1][i];
                                Guardar[2][cont] = Desarrollador.PI8[2][i];
                                Guardar[3][cont] = Desarrollador.PI8[3][i];

                            }
                            if (Desarrollador.contadores[7] > 0) {
                                Desarrollador.contadores[7]--;
                            }
                            Desarrollador.PI8 = null;
                            Desarrollador.PI8 = Guardar;

                        } else {
                            Desarrollador.PI8[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[8] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a editar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI9[0], Desarrollador.PI9[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[8]; i++) {
                            if (Desarrollador.PI9[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2]))) {
                            
                            if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI1[0][Desarrollador.PI1.length+1]=who.toString();
                                Desarrollador.PI1[1][Desarrollador.PI1.length+1]=Atarea;
                                Desarrollador.PI1[2][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.PI1[3][Desarrollador.PI1.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[0]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI2[0][Desarrollador.PI2.length+1]=who.toString();
                                Desarrollador.PI2[1][Desarrollador.PI2.length+1]=Atarea;
                                Desarrollador.PI2[2][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.PI2[3][Desarrollador.PI2.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[1]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI3[0][Desarrollador.PI3.length+1]=who.toString();
                                Desarrollador.PI3[1][Desarrollador.PI3.length+1]=Atarea;
                                Desarrollador.PI3[2][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.PI3[3][Desarrollador.PI3.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[2]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI4[0][Desarrollador.PI4.length+1]=who.toString();
                                Desarrollador.PI4[1][Desarrollador.PI4.length+1]=Atarea;
                                Desarrollador.PI4[2][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.PI4[3][Desarrollador.PI4.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[3]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI5[0][Desarrollador.PI5.length+1]=who.toString();
                                Desarrollador.PI5[1][Desarrollador.PI5.length+1]=Atarea;
                                Desarrollador.PI5[2][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.PI5[3][Desarrollador.PI5.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[4]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI6[0][Desarrollador.PI6.length+1]=who.toString();
                                Desarrollador.PI6[1][Desarrollador.PI6.length+1]=Atarea;
                                Desarrollador.PI6[2][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.PI6[3][Desarrollador.PI6.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[5]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0])){
                                Desarrollador.PI7[0][Desarrollador.PI7.length+1]=who.toString();
                                Desarrollador.PI7[1][Desarrollador.PI7.length+1]=Atarea;
                                Desarrollador.PI7[2][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.PI7[3][Desarrollador.PI7.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[6]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1])){
                                Desarrollador.PI8[0][Desarrollador.PI8.length+1]=who.toString();
                                Desarrollador.PI8[1][Desarrollador.PI8.length+1]=Atarea;
                                Desarrollador.PI8[2][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.PI8[3][Desarrollador.PI8.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[7]++;
                            }
                            else if(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2])){
                                Desarrollador.PI9[0][Desarrollador.PI9.length+1]=who.toString();
                                Desarrollador.PI9[1][Desarrollador.PI9.length+1]=Atarea;
                                Desarrollador.PI9[2][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.PI9[3][Desarrollador.PI9.length+1]=opcionPrio.toString();
                                Desarrollador.contadores[8]++;
                            }
                            else{}
                            
                            String Guardar[][] = new String[4][(Desarrollador.contadores[8]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI9[0][i];
                                Guardar[1][i] = Desarrollador.PI9[1][i];
                                Guardar[2][i] = Desarrollador.PI9[2][i];
                                Guardar[3][i] = Desarrollador.PI9[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[8]) - 1); i++) {
                                Guardar[0][cont] = Desarrollador.PI9[0][i];
                                Guardar[1][cont] = Desarrollador.PI9[1][i];
                                Guardar[2][cont] = Desarrollador.PI9[2][i];
                                Guardar[3][cont] = Desarrollador.PI9[3][i];

                            }
                            if (Desarrollador.contadores[8] > 0) {
                                Desarrollador.contadores[8]--;
                            }
                            Desarrollador.PI9 = null;
                            Desarrollador.PI9 = Guardar;

                        } else {
                            Desarrollador.PI9[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else {
                        JOptionPane.showMessageDialog(null, "Seleccionaste un sector vacio sin Post-Its");
                    }
                    updateUI();
                } //ELIMINAR POST-IT:
                else if(opcion.equals(OP[0])){
                    String[] Aproceso = {"Planeacion", "En Proceso", "Finalizado"};
                    String[] Aprioridad = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                    Object Prio = JOptionPane.showInputDialog(null, "Seleccione la Prioridad del Post-It a editar:", "EDITAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridad, Aprioridad[0]);
                    Object Proc = JOptionPane.showInputDialog(null, "Seleccione el Proceso del Post-It a editar:", "EDITAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                    if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[0] >= 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI1[0], Desarrollador.PI1[0][0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[0]; i++) {
                            if (Desarrollador.PI1[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }

                        String Guardar[][] = new String[4][(Desarrollador.contadores[0]) - 1];
                        for (int i = 0; i < cont; i++) {
                            Guardar[0][i] = Desarrollador.PI1[0][i];
                            Guardar[1][i] = Desarrollador.PI1[1][i];
                            Guardar[2][i] = Desarrollador.PI1[2][i];
                            Guardar[3][i] = Desarrollador.PI1[3][i];
                        }
                        for (int i = cont; i < ((Desarrollador.contadores[0]) - 1); i++) {
                            Guardar[0][1 - cont] = Desarrollador.PI1[0][i];
                            Guardar[1][1 - cont] = Desarrollador.PI1[1][i];
                            Guardar[2][1 - cont] = Desarrollador.PI1[2][i];
                            Guardar[3][1 - cont] = Desarrollador.PI1[3][i];

                        }
                        if (Desarrollador.contadores[0] > 0) {
                            Desarrollador.contadores[0]--;
                        }
                        Desarrollador.PI1 = null;
                        Desarrollador.PI1 = Guardar;

                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[1] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI2[0], Desarrollador.PI2[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[1]; i++) {
                            if (Desarrollador.PI2[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[1]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[1]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI2[0][i];
                                Guardar[1][i] = Desarrollador.PI2[1][i];
                                Guardar[2][i] = Desarrollador.PI2[2][i];
                                Guardar[3][i] = Desarrollador.PI2[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[1]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI1[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI1[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI1[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI1[3][i];

                            }
                            if (Desarrollador.contadores[1] > 0) {
                                Desarrollador.contadores[1]--;
                            }
                            Desarrollador.PI2 = null;
                            Desarrollador.PI2 = Guardar;

                        } else {
                            Desarrollador.PI2[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[0]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[2] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI3[0], Desarrollador.PI3[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[2]; i++) {
                            if (Desarrollador.PI3[2][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[0]) && opcionPro.equals(Aproceso[2]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[2]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI3[0][i];
                                Guardar[1][i] = Desarrollador.PI3[1][i];
                                Guardar[2][i] = Desarrollador.PI3[2][i];
                                Guardar[3][i] = Desarrollador.PI3[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[2]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI3[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI3[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI3[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI3[3][i];

                            }
                            if (Desarrollador.contadores[2] > 0) {
                                Desarrollador.contadores[2]--;
                            }
                            Desarrollador.PI3 = null;
                            Desarrollador.PI3 = Guardar;

                        } else {
                            Desarrollador.PI3[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[3] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI4[0], Desarrollador.PI4[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[3]; i++) {
                            if (Desarrollador.PI4[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[0]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[3]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI4[0][i];
                                Guardar[1][i] = Desarrollador.PI4[1][i];
                                Guardar[2][i] = Desarrollador.PI4[2][i];
                                Guardar[3][i] = Desarrollador.PI4[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[3]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI4[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI4[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI4[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI4[3][i];

                            }
                            if (Desarrollador.contadores[3] > 0) {
                                Desarrollador.contadores[3]--;
                            }
                            Desarrollador.PI4 = null;
                            Desarrollador.PI4 = Guardar;

                        } else {
                            Desarrollador.PI4[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[4] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI5[0], Desarrollador.PI5[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[4]; i++) {
                            if (Desarrollador.PI5[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[1]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[4]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI5[0][i];
                                Guardar[1][i] = Desarrollador.PI5[1][i];
                                Guardar[2][i] = Desarrollador.PI5[2][i];
                                Guardar[3][i] = Desarrollador.PI5[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[4]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI5[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI5[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI5[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI5[3][i];

                            }
                            if (Desarrollador.contadores[4] > 0) {
                                Desarrollador.contadores[4]--;
                            }
                            Desarrollador.PI5 = null;
                            Desarrollador.PI5 = Guardar;

                        } else {
                            Desarrollador.PI5[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[1]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[5] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI6[0], Desarrollador.PI6[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[5]; i++) {
                            if (Desarrollador.PI6[0][i].equals(who)) {

                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[1]) && opcionPro.equals(Aproceso[2]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[0]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI6[0][i];
                                Guardar[1][i] = Desarrollador.PI6[1][i];
                                Guardar[2][i] = Desarrollador.PI6[2][i];
                                Guardar[3][i] = Desarrollador.PI6[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[0]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI6[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI6[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI6[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI6[3][i];

                            }
                            if (Desarrollador.contadores[5] > 0) {
                                Desarrollador.contadores[5]--;
                            }
                            Desarrollador.PI6 = null;
                            Desarrollador.PI6 = Guardar;

                        } else {
                            Desarrollador.PI6[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[0]) && Desarrollador.contadores[6] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI7[0], Desarrollador.PI7[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[6]; i++) {
                            if (Desarrollador.PI1[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[0]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[6]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI7[0][i];
                                Guardar[1][i] = Desarrollador.PI7[1][i];
                                Guardar[2][i] = Desarrollador.PI7[2][i];
                                Guardar[3][i] = Desarrollador.PI7[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[6]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI7[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI7[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI7[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI7[3][i];

                            }
                            if (Desarrollador.contadores[6] > 0) {
                                Desarrollador.contadores[6]--;
                            }
                            Desarrollador.PI7 = null;
                            Desarrollador.PI7 = Guardar;

                        } else {
                            Desarrollador.PI7[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[1]) && Desarrollador.contadores[7] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI8[0], Desarrollador.PI8[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[7]; i++) {
                            if (Desarrollador.PI8[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[1]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[7]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI8[0][i];
                                Guardar[1][i] = Desarrollador.PI8[1][i];
                                Guardar[2][i] = Desarrollador.PI8[2][i];
                                Guardar[3][i] = Desarrollador.PI8[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[7]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI8[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI8[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI8[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI8[3][i];

                            }
                            if (Desarrollador.contadores[7] > 0) {
                                Desarrollador.contadores[7]--;
                            }
                            Desarrollador.PI8 = null;
                            Desarrollador.PI8 = Guardar;

                        } else {
                            Desarrollador.PI8[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else if (Prio.equals(Aprioridad[2]) && Proc.equals(Aproceso[2]) && Desarrollador.contadores[8] > 0) {
                        Object who = JOptionPane.showInputDialog(null, "Seleccione la persona o el equipo del Post-It a eliminar:", "EDITAR POST-IT", JOptionPane.QUESTION_MESSAGE, null, Desarrollador.PI9[0], Desarrollador.PI9[0][0]);
                        String Atarea = JOptionPane.showInputDialog("Especifique la tarea a realizar");
                        String[] Aprioridades = {"Baja Prioridad", "Mediana Prioridad", "Alta Prioridad"};
                        Object opcionPrio = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PRIORIDAD", JOptionPane.QUESTION_MESSAGE, null, Aprioridades, Aprioridades[0]);
                        Object opcionPro = JOptionPane.showInputDialog(null, "Selecciona una Prioridad:", "AGREGAR POST-IT - PROCESO", JOptionPane.QUESTION_MESSAGE, null, Aproceso, Aproceso[0]);
                        int cont = 0;
                        for (int i = 0; i < Desarrollador.contadores[8]; i++) {
                            if (Desarrollador.PI9[0][i].equals(who)) {
                                break;
                            } else {
                                cont++;
                            }
                        }
                        if (!(opcionPrio.equals(Aprioridades[2]) && opcionPro.equals(Aproceso[2]))) {
                            String Guardar[][] = new String[4][(Desarrollador.contadores[8]) - 1];
                            for (int i = 0; i < cont; i++) {
                                Guardar[0][i] = Desarrollador.PI9[0][i];
                                Guardar[1][i] = Desarrollador.PI9[1][i];
                                Guardar[2][i] = Desarrollador.PI9[2][i];
                                Guardar[3][i] = Desarrollador.PI9[3][i];
                            }
                            for (int i = cont; i < ((Desarrollador.contadores[8]) - 1); i++) {
                                Guardar[0][1 - cont] = Desarrollador.PI9[0][i];
                                Guardar[1][1 - cont] = Desarrollador.PI9[1][i];
                                Guardar[2][1 - cont] = Desarrollador.PI9[2][i];
                                Guardar[3][1 - cont] = Desarrollador.PI9[3][i];

                            }
                            if (Desarrollador.contadores[8] > 0) {
                                Desarrollador.contadores[8]--;
                            }
                            Desarrollador.PI9 = null;
                            Desarrollador.PI9 = Guardar;

                        } else {
                            Desarrollador.PI9[1][cont] = Atarea;
                        }
                        PanelBoard.BOARD = null;
                        //vacear paneles
                        PanelBoard.BOARD = new PanelBoard();
                        updateUI();

                    } else {
                        JOptionPane.showMessageDialog(null, "Seleccionaste un sector vacio sin Post-Its");
                    }
                    updateUI();
                }

            }
        });

        importar = new JButton(new ImageIcon("./src/Imagenes/Cargar.png"));
        //Se le brinda una imagen al boton de importar y se agrega en el panel
        importar.setBorder(null);
        importar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                //Cuando el usuario pulse el botÃ³n de importar archivo se ejecutarÃ¡ lo siguiente
                try {
                    if (importarUnaVez == 1) {
                        //importar solo se usarÃ¡ una vez y por ello se llama una funcion de 
                        //la clase desarrollador usando herencia
                        //dicha funcion ejecutarÃ¡ diversas manipulaciones de informacion para sacar
                        //los Post-its de un TxT

                        Desarrollador.agregarArchivo();
                        //Una vez que termine de importar el TxT, la variable se pondrÃ¡ en 0
                        //para que no se pueda ejecutar mÃ¡s de 1 vez
                        importarUnaVez = 0;
                        // Se actualiza la interfaz para que se muestren los cambios
                        updateUI();
                    } else {
                        // Si el usuario trata de importar mÃ¡s de 1 vez un TxT saldrÃ¡ el mensaje
                        JOptionPane.showMessageDialog(null, "Ya importaste el archivo");
                    }

                } catch (IOException ex) {
                    Logger.getLogger(PanelUP.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        exportar = new JButton(new ImageIcon("./src/Imagenes/Guardar.png"));
        // Se le dÃ¡ un icono al botÃ³n de exportar y se agrega a la interfaz
        exportar.setBorder(null);
        exportar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                JOptionPane.showMessageDialog(null, "Esta funcion crea un archivo, pero aun no se ha podido escribir el contenido en este archivo");
                //Funciones que se ejecutan al dar click en el botÃ³n exportar
                //se usa herencia para llamar la funciÃ³n desde desarrollador
                File miArchivo;
                PrintWriter escribir;

                miArchivo = new File("./src/Archivos/KanBan.txt");
                if (!miArchivo.exists()) {

                    try {
                        miArchivo.createNewFile();
                    } catch (IOException ex) {
                        Logger.getLogger(Desarrollador.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } else {
                    try {
                        escribir = new PrintWriter(miArchivo, "utf-8");

                        int postits = (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length);
                        postits = postits + (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length);
                        postits = postits + (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length) + (Desarrollador.PI1[0].length);

                        String Salida[][] = new String[5][postits];
                        for (int i = 0; i < postits; i++) {
                            if (i < Desarrollador.PI1.length) {
                                Salida[0][i] = Desarrollador.PI1[0][i];
                                Salida[1][i] = Desarrollador.PI1[0][i];
                                Salida[2][i] = Desarrollador.PI1[0][i];
                                Salida[3][i] = Desarrollador.PI1[0][i];
                            }
                            else if (i < Desarrollador.PI1.length+Desarrollador.PI2.length) {
                                Salida[0][i] = Desarrollador.PI1[0][i];
                                Salida[1][i] = Desarrollador.PI1[0][i];
                                Salida[2][i] = Desarrollador.PI1[0][i];
                                Salida[3][i] = Desarrollador.PI1[0][i];
                            }
                            //CONTINUAR PARA TENER UN ARREGLO COMPLETO PARA EXPORTAR...
                        }

                        escribir.write("El numero de Post-its es: " + postits);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

            }
        });

        salir = new JButton(new ImageIcon("./src/Imagenes/Salir.png"));
        //Se le dÃ¡ un icono al botÃ³n de Salir y se agrega a la interfaz
        salir.setBorder(null);
        salir.addActionListener(new ActionListener() {
            //Cuando el usuario le dÃ© click al botÃ³n salir , ejecutarÃ¡ el sig , comando
            //Que cerrarÃ¡ el programa y todos sus procesos
            @Override
            public void actionPerformed(ActionEvent arg0) {
                System.exit(0);
            }
        });

        //Se agregan todos sus botones con sus respectivas imagenes
        up.add(logo);
        up.add(agregar);

        up.add(editar);
        up.add(importar);
        up.add(exportar);
        up.add(salir);

        //Se edita la visibilidad de el panel
        up.setVisible(true);

        return up;
    }

    public JPanel abajo() {
        down = new JPanel();
        titulo = new JLabel(new ImageIcon("./src/Imagenes/LOGO2.png"));

        down.add(titulo);

        down.setVisible(true);
        return down;
    }

}
