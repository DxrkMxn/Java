
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.io.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 */
public class Main extends JFrame {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        //Desarrollador.ingresarArreglo(0,0,0,0,0,0,0,0,0);
        Desarrollador a = new Desarrollador();
        a.LeerTxT("./src/Archivos/file.txt");
        GUI ventana = new GUI();

    }

}
