
import java.awt.Component;
import java.awt.GridLayout;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 * @throws java.io.IOException
 */
public class PanelLeft extends JPanel {

    /**
     * @throws java.io.IOException
     */
    private JPanel LEFT;
    private JLabel baja, media, alta;

    public PanelLeft() throws IOException {
        // Se le da valores a sus variables y se les denomina como Jlabels , poniendoles una imagen
        // que denominarÃ¡ las prioridades del tablero
        //ubicadas en la parte izquiera de la ventana
        LEFT = new JPanel();

        LEFT.setLayout(new GridLayout(3, 1));

        baja = new JLabel(new ImageIcon("./src/Imagenes/Left.png"));
        media = new JLabel("PRIORIDAD MEDIA");
        alta = new JLabel("PRIORIDAD ALTA");

        LEFT.add(baja);
        //LEFT.add(media);
        //LEFT.add(alta);

        this.add(LEFT);

    }

}
