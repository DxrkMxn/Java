
import java.awt.BorderLayout;
import java.io.IOException;
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 *
 */
class GUI extends JFrame {

    /**
     * @throws java.io.IOException
     */
    public GUI() throws IOException {

        JFrame Ventana = new JFrame("MATRIZ KAN-BAN");
        //Atributos de la Ventana:
        Ventana.setSize(1200, 800); // TAMANO DE LA VENTANA
        Ventana.setResizable(false); // BLOQUEO DE CAMBIO DE TAMANO DE VENTANA
        Ventana.setLocationRelativeTo(null); // QUE LA VENTANA SE INICIALICE EN EL CENTRO DE LA PANTALLA
        Ventana.setLayout(new BorderLayout());
        //Paneles de la Ventana:
        Ventana.add(new PanelUP(), BorderLayout.NORTH); //SE AGREGA EL PANEL SUPERIOR
        Ventana.add(new PanelLeft(), BorderLayout.WEST); // SE AGREGA EL PANEL DE LA IZQUIERDA
        Ventana.add(new PanelBoard(), BorderLayout.CENTER); // SE AGREGA LA MATRIZ KANBAN
        Ventana.setUndecorated(true);
        Ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // SE DEFINE EL CIEERE DE LA VENTANA AL PRESIONAR [X]
        Ventana.setVisible(true); // VENTANA VISIBLE

    }

}
