/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 */
public class Desarrollador {

    //Creamos variables de cÃ¡racter pÃºblico (encapsulamiento) para que se puedan usar durante todo  
    //el programa de manera libre , ya sea en metodos de una clase , o en otras clases diferentes
    public static String Postit[][], MatrizBeta[][], PI1[][], PI2[][], PI3[][], PI4[][], PI5[][], PI6[][], PI7[][], PI8[][], PI9[][];
    public static int contadorTxT, contador, contadoresTxT[], contadores[];

    public Desarrollador() throws IOException {
        //Iniciamos todas las matrices con un tamaÃ±o de 4 filas con 0 columnas , para que tengan
        // los 4 atributos de un post-it ( Nombre , tarea , prioridad y estado)
        PI1 = new String[4][0];

        PI2 = new String[4][0];

        PI3 = new String[4][0];
        //
        PI4 = new String[4][0];

        PI5 = new String[4][0];

        PI6 = new String[4][0];

        PI7 = new String[4][0];

        PI8 = new String[4][0];

        PI9 = new String[4][0];

        contadores = new int[9];
        for (int i = 0; i < 9; i++) {
            contadores[i] = 0;
        }
    }

    public void agregarPostIt(String KBold[][], String nKB[]) {
        // Aqui usamos una funcion de un arreglo de string  y una matriz string
        // para poder crear un nuevo Post-it , teniendo en cuenta si ya hay o no
        // post-its ya en el programa registrados , se usan las mismas 4 cualidades 
        // nombre , tarea , estado , prioridad.
        String[][] N = new String[4][((KBold[0].length) + 1)];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < KBold[0].length; j++) {
                N[i][j] = KBold[i][j];
            }

        }
        for (int i = 0; i < 4; i++) {

            N[i][(KBold[0].length) + 1] = nKB[i];
        }
        KBold = null;
        KBold = N;
    }
    // hay  que tener en cuenta que todas las funciones son publicas para que las demÃ¡s clases puedan usar
    // estos metodos si son necesarios para editar o guardar informaciÃ³n.

    public void LeerTxT(String direccion) {   //Primero Direccionamos la ruta para leer el archivo

        try {
            BufferedReader bf = new BufferedReader(new FileReader(direccion));
            //inicializamos arreglos para las posibles prioridades y los posibles estados
            String prioridades[] = new String[3];
            String estados[] = new String[3];
            //inicializados una variable estado y una variable prioridad
            String estado = " ";
            String prioridad = " ";
            //como todos los Post-it solo tienen 4 datos entonces las filas son 4 siempre
            int Filas = 5;
            //contadores representa los contadores para las 9 regiones del KanBan
            contadoresTxT = new int[9];
            //Contador me representara cuantas columnas de mi matriz beta para post-it deben haber y
            // a su vez me va a registrar la cantidad de Post-it que Se introduciran
            contadorTxT = Integer.parseInt(bf.readLine());
            //iniciamos la Matriz Beta para guardar temporalmente los Post-its
            MatrizBeta = new String[Filas][contadorTxT];
            for (int i = 0; i < Filas; i++) {
                for (int j = 0; j < contadorTxT; j++) {
                    if (i != 4) {
                        MatrizBeta[i][j] = bf.readLine();
                    } else {
                        MatrizBeta[i][j] = null;

                    }
                }
            }

            // Le damos valores a los arreglos de Prioridades y Estados
            for (int i = 0; i < 1; i++) {
                prioridades[i] = "Baja Prioridad";
                prioridades[i + 1] = "Media Prioridad";
                prioridades[i + 2] = "Alta Prioridad";
                estados[i] = "Planeacion";
                estados[i + 1] = "En Proceso";
                estados[i + 2] = "Finalizado";
            }
            //Empezamos procesos de comparacion para saber cuantos Post-its de cada regiÃ³n van a haber
            // Se almacenan en el arreglo "Contadores[]" que habiamos inicializado antes
            // cada posicion de mi arreglo representa una regiÃ³n en KanBan
            for (int j = 0; j < contadorTxT; j++) {
                for (int i = 0; i < Filas; i++) {

                    if (i == 2) {
                        estado = MatrizBeta[i][j];
                    }
                    if (i == 3) {
                        prioridad = MatrizBeta[i][j];
                        if (estado.equals(estados[0]) && prioridad.equals(prioridades[0])) {
                            contadoresTxT[0]++;
                            MatrizBeta[i + 1][j] = "KB1";
                        } else {
                        }
                        if (estado.equals(estados[1]) && prioridad.equals(prioridades[0])) {
                            contadoresTxT[1]++;
                            MatrizBeta[i + 1][j] = "KB2";
                        } else {
                        }
                        if (estado.equals(estados[2]) && prioridad.equals(prioridades[0])) {
                            contadoresTxT[2] = +1;
                            MatrizBeta[i + 1][j] = "KB3";
                        } else {
                        }
                        if (estado.equals(estados[0]) && prioridad.equals(prioridades[1])) {
                            contadoresTxT[3]++;
                            MatrizBeta[i + 1][j] = "KB4";
                        } else {
                        }
                        if (estado.equals(estados[1]) && prioridad.equals(prioridades[1])) {
                            contadoresTxT[4]++;
                            MatrizBeta[i + 1][j] = "KB5";
                        } else {
                        }
                        if (estado.equals(estados[2]) && prioridad.equals(prioridades[1])) {
                            contadoresTxT[5]++;
                            MatrizBeta[i + 1][j] = "KB6";
                        } else {
                        }
                        if (estado.equals(estados[0]) && prioridad.equals(prioridades[2])) {
                            contadoresTxT[6]++;
                            MatrizBeta[i + 1][j] = "KB7";
                        } else {
                        }
                        if (estado.equals(estados[1]) && prioridad.equals(prioridades[2])) {
                            contadoresTxT[7]++;
                            MatrizBeta[i + 1][j] = "KB8";
                        } else {
                        }
                        if (estado.equals(estados[2]) && prioridad.equals(prioridades[2])) {
                            contadoresTxT[8]++;
                            MatrizBeta[i + 1][j] = "KB9";
                        } else {
                        }
                    } else {
                    }
                }
            }

            //Realizamos impresiones para verificar que mi informacion se guardo correctamente 
            // y en el orden correcto en mi MatrizBeta , cada Columna representa un Post-it diferente
            String Datos[] = new String[5];
            Datos[0] = "Nombre desarrollador";
            Datos[1] = "Tarea";
            Datos[2] = "Estado";
            Datos[3] = "Prioridad";
            Datos[4] = "Region";
            for (int j = 0; j < contadorTxT; j++) {
                System.out.println("");
                System.out.println("");
                System.out.print("El Post-it NÂ°" + (j + 1) + " " + "Tiene los siguientes datos:");
                for (int i = 0; i < Filas; i++) {
                    System.out.println();
                    System.out.print(Datos[i] + ":");
                    System.out.println();
                    System.out.print(MatrizBeta[i][j]);
                }
            }

            //hacemos proceso para verificar que mis contadores del arreglo "Contadores[]" al sumarlos
            //Me dan exactamente la cantidad de Post-It que se metieron en el txt
            //Para eso se compara con la variable "contador" que hace el papel de saber cuantos son
            int hola = 0;

            System.out.println();
            for (int i = 0; i < 9; i++) {
                hola = hola + contadoresTxT[i];
            }
            System.out.println();
            System.out.println("La cantidad de Post-its es :" + contadorTxT);
            System.out.println();
            System.out.println("La cantidad de Post-its en total de la matriz es:" + hola);

            for (int i = 0; i < 9; i++) {
                System.out.println(contadoresTxT[i]);
            }

        } catch (Exception e) {
            System.err.println("No se encuontra el archivo");
        }

        contador = contadorTxT;

        for (int i = 0; i < 9; i++) {
            contadores[i] += contadoresTxT[i];

        }

    }

    public static void ingresarArreglo(String K) {

        if (K.equals("UYY")) {
            Postit = new String[contador][4];
            for (int j = 0; j < contador; j++) {
                Postit[j][0] = ("Persona" + (j + 1));
                Postit[j][1] = "Tarea";
                Postit[j][2] = "Proceso";
                Postit[j][3] = "Prioridad";
            }
        } else {
            Postit = new String[contador][4];
            for (int j = 0; j < contador; j++) {
                Postit[j][0] = ("Nombre Persona" + (j + 1));
                Postit[j][1] = "Tarea a Realizar";
                Postit[j][2] = "En Proceso";
                Postit[j][3] = "Baja Prioridad";
            }
        }

    }

    public static void agregarArchivo() throws IOException {

        // Usando la funciÃ³n anterior pasamos a importar el archivo desde la interfaz KanBan
        JOptionPane.showMessageDialog(null, "Acabas de Importar el Archivo: file.txt");

        // Inicializamos las Matrices correspondientes a las 9 regiones del KanBan 
        // Todas deben ser iniciadas con la cantidad de Post-its correspondientes para su dicha matriz
        // vease ahi porque "contadores" lleva un numero diferente en cada "PI" , ya que la cantidad de
        //Post-its de PI1 no es igual a las de PI8 por ejemplo , y contadores al ser un arreglo 
        // ya tiene en cada posicion la cantidad correspondiente a cada "PI"
        PI1 = new String[4][contadores[0]];
        PI2 = new String[4][contadores[1]];
        PI3 = new String[4][contadores[2]];
        PI4 = new String[4][contadores[3]];
        PI5 = new String[4][contadores[4]];
        PI6 = new String[4][contadores[5]];
        PI7 = new String[4][contadores[6]];
        PI8 = new String[4][contadores[7]];
        PI9 = new String[4][contadores[8]];

        // Se inician variables para usarlas en lugar de in i o un j
        int c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0, c7 = 0, c8 = 0, c9 = 0;
        for (int i = 0; i < contador; i++) {
            //Se realiza un for para analizar los Post-its que esten en la matriz resultante de
            //La funcion LeerTxT , seguido a esto se efectuan comparaciones y se decide 
            // si se usarÃ¡ PI1 - PI9 para guardar la informacion de ese Post-it
            if (MatrizBeta[4][i].equals("KB1")) {
                PI1[0][c1] = MatrizBeta[0][i];
                PI1[1][c1] = MatrizBeta[1][i];
                PI1[2][c1] = MatrizBeta[2][i];
                PI1[3][c1] = MatrizBeta[3][i];
                c1++;
            } else if (MatrizBeta[4][i].equals("KB2")) {
                PI2[0][c2] = MatrizBeta[0][i];
                PI2[1][c2] = MatrizBeta[1][i];
                PI2[2][c2] = MatrizBeta[2][i];
                PI2[3][c2] = MatrizBeta[3][i];
                c2++;
            } else if (MatrizBeta[4][i].equals("KB3")) {
                PI3[0][c3] = MatrizBeta[0][i];
                PI3[1][c3] = MatrizBeta[1][i];
                PI3[2][c3] = MatrizBeta[2][i];
                PI3[3][c3] = MatrizBeta[3][i];
                c3++;
            } else if (MatrizBeta[4][i].equals("KB4")) {
                PI4[0][c4] = MatrizBeta[0][i];
                PI4[1][c4] = MatrizBeta[1][i];
                PI4[2][c4] = MatrizBeta[2][i];
                PI4[3][c4] = MatrizBeta[3][i];
                c4++;
            } else if (MatrizBeta[4][i].equals("KB5")) {
                PI5[0][c5] = MatrizBeta[0][i];
                PI5[1][c5] = MatrizBeta[1][i];
                PI5[2][c5] = MatrizBeta[2][i];
                PI5[3][c5] = MatrizBeta[3][i];
                c5++;
            } else if (MatrizBeta[4][i].equals("KB6")) {
                PI6[0][c6] = MatrizBeta[0][i];
                PI6[1][c6] = MatrizBeta[1][i];
                PI6[2][c6] = MatrizBeta[2][i];
                PI6[3][c6] = MatrizBeta[3][i];
                c6++;
            } else if (MatrizBeta[4][i].equals("KB7")) {
                PI7[0][c7] = MatrizBeta[0][i];
                PI7[1][c7] = MatrizBeta[1][i];
                PI7[2][c7] = MatrizBeta[2][i];
                PI7[3][c7] = MatrizBeta[3][i];
                c7++;
            } else if (MatrizBeta[4][i].equals("KB8")) {
                PI8[0][c8] = MatrizBeta[0][i];
                PI8[1][c8] = MatrizBeta[1][i];
                PI8[2][c8] = MatrizBeta[2][i];
                PI8[3][c8] = MatrizBeta[3][i];
                c8++;
            } else if (MatrizBeta[4][i].equals("KB9")) {
                PI9[0][c9] = MatrizBeta[0][i];
                PI9[1][c9] = MatrizBeta[1][i];
                PI9[2][c9] = MatrizBeta[2][i];
                PI9[3][c9] = MatrizBeta[3][i];
                c9++;
            }
        }

        // se empiezan a crear los botones correspondientes para los Post-its ingresados
        //desde el archivo TxT , se usa herencia para llamar a la clase panelBoard y agregarle 
        // los botones con los nombres en las matrices PI1-PI9
        for (int i = 0; i < contadores[0]; i++) {

            int c = i;
            PanelBoard.PostitOld = new JButton(PI1[0][c]);

            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    //Se ejecuta una ventana emergente que muestra el nombre , tarea , prioridad y estado
                    // solamente cuando se hace click sobre el Post-it que desea conocer sus datos
                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI1[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI1[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI1[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI1[3][c]);
                    mostrar.add(Q);

                }
            });
            // Se usa herencia en PanelBoard para darle valor a una variable de dicha clase
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[0]; i++) {
            //Se usa herencia para agregar los botones en PanelBoard , en la region KanBan correspondiente
            PanelBoard.KB1.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[1]; i++) {

            int c = i;
            PanelBoard.PostitOld = new JButton(PI2[0][c]);

            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI2[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI2[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI2[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI2[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 9; i < contadores[1]; i++) {

            PanelBoard.KB2.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[2]; i++) {

            int c = i;
            PanelBoard.PostitOld = new JButton(PI3[0][c]);

            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI3[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI3[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI3[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI3[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[2]; i++) {

            PanelBoard.KB3.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[3]; i++) {

            int c = i;
            PanelBoard.PostitOld = new JButton(PI4[0][c]);

            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI4[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI4[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI4[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI4[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[3]; i++) {

            PanelBoard.KB4.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[4]; i++) {
            PanelBoard.PostitOld = new JButton(PI5[0][i]);
            int c = i;
            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI5[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI5[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI5[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI5[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[4]; i++) {

            PanelBoard.KB5.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[5]; i++) {
            PanelBoard.PostitOld = new JButton(PI6[0][i]);
            int c = i;
            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI6[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI6[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI6[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI6[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < Desarrollador.contadores[5]; i++) {

            PanelBoard.KB6.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[6]; i++) {
            PanelBoard.PostitOld = new JButton(PI7[0][i]);
            int c = i;
            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI7[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI7[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI7[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI7[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[6]; i++) {

            PanelBoard.KB7.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[7]; i++) {
            PanelBoard.PostitOld = new JButton(PI8[0][i]);
            int c = i;
            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI8[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI8[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI8[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("   Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI8[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[7]; i++) {

            PanelBoard.KB8.add(PanelBoard.Postits[i]);
        }

        for (int i = 0; i < contadores[8]; i++) {
            PanelBoard.PostitOld = new JButton(PI9[0][i]);
            int c = i;
            PanelBoard.PostitOld.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {

                    JFrame mostrar;
                    mostrar = new JFrame();
                    mostrar.setSize(400, 300);
                    mostrar.setResizable(false);
                    mostrar.setLocationRelativeTo(null);
                    mostrar.setVisible(true);
                    mostrar.setLayout(new GridLayout(4, 2, 2, 2));
                    JLabel n = new JLabel("  Nombre: ");
                    mostrar.add(n);
                    JLabel N = new JLabel(PI9[0][c]);
                    mostrar.add(N);
                    JLabel t = new JLabel("  Tarea: ");
                    mostrar.add(t);
                    JLabel T = new JLabel(PI9[1][c]);
                    mostrar.add(T);
                    JLabel p = new JLabel("  Se encuentra en: ");
                    mostrar.add(p);
                    JLabel P = new JLabel(PI9[2][c]);
                    mostrar.add(P);
                    JLabel q = new JLabel("  Prioridad: ");
                    mostrar.add(q);
                    JLabel Q = new JLabel(PI9[3][c]);
                    mostrar.add(Q);

                }
            });
            PanelBoard.Postits[i] = PanelBoard.PostitOld;
        }
        for (int i = 0; i < contadores[8]; i++) {

            PanelBoard.KB9.add(PanelBoard.Postits[i]);

        }

    }

    public static void exportarArchivo() {

        JOptionPane.showMessageDialog(null, "Presionaste Exportar");

    }

    public static void editarPostit() {

        JOptionPane.showMessageDialog(null, "Presionaste Editar");

    }

}
