
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ing. Jhusef Alfonso L�pez Parra
 */
public class PanelBoard extends JPanel {

    // Se crean variables de tipo publicas , para que sean usadas en diversas clases del programa
    // Para que se editen o se usen sus datos correspondientes.
    public static JPanel BOARD, KB1, KB2, KB3, KB4, KB5, KB6, KB7, KB8, KB9;
    public static JButton PostitOld, PostitNew, Postits[];

    public PanelBoard() {

        // Se crea el tablero del KanBan para el centro de todo el BorderLayout 
        // Se inicia con un GridLayout donde se anexaran las regiones para el KanBan
        // estas mismas se les denomina con "Kb" y un numero que va desde 1-9
        BOARD = new JPanel();
        Postits = new JButton[9];
        BOARD.setLayout(new GridLayout(3, 3, 10, 10));
        BOARD.add(KB1());
        BOARD.add(KB2(), BorderLayout.NORTH);
        BOARD.add(KB3());
        BOARD.add(KB4(), BorderLayout.WEST);
        BOARD.add(KB5(), BorderLayout.CENTER);
        BOARD.add(KB6(), BorderLayout.EAST);
        BOARD.add(KB7());
        BOARD.add(KB8(), BorderLayout.SOUTH);
        BOARD.add(KB9());
        setLayout(new GridLayout());
        this.add(BOARD);

    }

    public JPanel KB1() {
        //Primera regiÃ³n del KanBan
        KB1 = new JPanel();

        KB1.setLayout(new GridLayout(3, 3));

        KB1.setBackground(Color.WHITE);

        return KB1;
    }

    private JPanel KB2() {
        //Segunda regiÃ³n de KanBan
        KB2 = new JPanel();

        KB2.setLayout(new GridLayout(3, 3));

        KB2.setBackground(Color.WHITE);

        return KB2;
    }

    private JPanel KB3() {
        //Tercera regiÃ³n de KanBan
        KB3 = new JPanel();
        KB3.setBackground(Color.WHITE);
        KB3.setLayout(new GridLayout(3, 3));

        return KB3;
    }

    private JPanel KB4() {
        //Cuarta regiÃ³n de KanBan
        KB4 = new JPanel();
        KB4.setBackground(Color.WHITE);
        KB4.setLayout(new GridLayout(3, 3));

        return KB4;
    }

    private JPanel KB5() {
        //Quinta regiÃ³n de KanBan
        KB5 = new JPanel();
        KB5.setBackground(Color.WHITE);
        KB5.setLayout(new GridLayout(3, 3));

        return KB5;
    }

    private JPanel KB6() {
        //Sexta regiÃ³n de KanBan
        KB6 = new JPanel();
        KB6.setBackground(Color.WHITE);
        KB6.setLayout(new GridLayout(3, 3));

        return KB6;
    }

    private JPanel KB7() {
        //Septima regiÃ³n de KanBan
        KB7 = new JPanel();
        KB7.setBackground(Color.WHITE);
        KB7.setLayout(new GridLayout(3, 3));

        return KB7;
    }

    private JPanel KB8() {
        //Octava regiÃ³n de KanBan
        KB8 = new JPanel();
        KB8.setBackground(Color.WHITE);
        KB8.setLayout(new GridLayout(3, 3));

        return KB8;
    }

    private JPanel KB9() {
        //Novena region KanBan
        KB9 = new JPanel();
        KB9.setBackground(Color.WHITE);

        KB9.setLayout(new GridLayout(3, 3));

        return KB9;
    }

}
