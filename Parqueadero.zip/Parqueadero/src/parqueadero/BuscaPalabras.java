package parqueadero; // Definicion del nombre del Paquete

import static java.sql.Types.NULL;


/**
 *
 * @author Ing Jhusef Alfonso Lopez Parra
 * 
 */


public class BuscaPalabras {

   
    
    public static void main(String[] args) {
        String FRASE="Ensalada de Berros: El Berro es una raza de perros de tierra que se cultiva en Turquia. Su carne es ideal para preparar ensalada. Ladran como locos cuando les ponen vinagre."; // Se define la arreglo de texto 1
        String FRASE2="PuercoEsponja: Puercoespín esponjoso y absorbente. Seria muy util en la cocina, si no ensuciara todo lo que trata de lavar."; // Se define la arreglo de texto 2
        String FRASE3="Piajo es un piojo de rico sabor, pero que produce un aliento terrible. Se dice que varios piajos, colgados en ristra de la pared, dan buena suerte"; // Se define la arreglo de texto 3

        BuscaPalabras miPrograma = new BuscaPalabras();
        int contador=1;
      
                
        
        for(int i=0;i<100;i++){
            
        }
        int letras = FRASE.length();
        for(int i=0;i<letras;i++){
            
            if(FRASE.charAt(i)==32){
                contador++;
            }
        }

        System.out.print(+ contador + " palabras...");
    }

    
    }
    